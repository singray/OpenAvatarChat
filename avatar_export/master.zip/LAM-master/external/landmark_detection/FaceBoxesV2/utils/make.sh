#!/usr/bin/env bash
python3 build.py build_ext --inplace

